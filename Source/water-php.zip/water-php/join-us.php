<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="join-us-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <h1>Join Us</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                
                <ul class="general">
                    
                    
                    <li class="border">
                        <div class="content-box no-pad type-1">
                            <div class="group">
                                <a target="_blank" href="mailto:apply@company.com?subject=Web+Analyst+Application" class="link title"> Google's CEO <span class="right apply">apply </span><span class="arrow"></span></a>
                            </div>
                            <div class="image">
                                <img src="http://lorempixel.com/500/170/?x=10" alt="Image">
                            </div>
                            <div class="content">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                            </div>  
                        </div>
                    </li>
                    
                    
                    <li class="border">
                        <div class="content-box no-pad type-1">
                            <div class="group">
                                <a target="_blank" href="mailto:apply@company.com?subject=UX+Designer+Application" class="link title"> UX Designer <span class="right apply">apply </span><span class="arrow"></span></a>
                            </div>
                            
                            <div class="content">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                            </div>  
                        </div>
                    </li>
                    
                    <li class="border">
                        <div class="content-box no-pad type-1">
                            <div class="group">
                                <a target="_blank" href="mailto:apply@company.com?subject=Web+Analyst+Application" class="link title"> Web Analyst<span class="right apply">apply </span><span class="arrow"></span></a>
                            </div>
                            
                            <div class="content">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                            </div>  
                        </div>
                    </li>
                    
                </ul>
                
                
            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
