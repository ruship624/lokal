<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="gallery-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <!--<h2>Water</h2>-->
                    <h1>Our Gallery</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                
                    
                <div class="gallery">
                    <ul>
                        <li>
                            <a href="gallery-detail.php" class="album-photo">
                                <span class="counter">01</span>
                                <img src="http://lorempixel.com/400/200/?x=1" alt="Album 1">
                            </a>
                            <a href="gallery-detail.php" class="album-detail group">
                                <span class="left"> Sharp Colors and Fonts </span>
                                <span class="right"> 3 </span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="gallery-detail.php" class="album-photo">
                                <span class="counter">02</span>
                                <img src="http://lorempixel.com/400/200/?x=2" alt="Album 2">
                            </a>
                            <a href="gallery-detail.php" class="album-detail group">
                                <span class="left"> Unlimited Creativity</span>
                                <span class="right"> 12 </span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="gallery-detail.php" class="album-photo">
                                <span class="counter">03</span>
                                <img src="http://lorempixel.com/400/200/?x=3" alt="Album 3">
                            </a>
                            <a href="gallery-detail.php" class="album-detail group">
                                <span class="left"> So many images!</span>
                                <span class="right"> 10 </span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="gallery-detail.php" class="album-photo">
                                <span class="counter">04</span>
                                <img src="http://lorempixel.com/400/200/?x=4" alt="Album 4">
                            </a>
                            <a href="gallery-detail.php" class="album-detail group">
                                <span class="left"> Keep going! We have loads of pictures!</span>
                                <span class="right"> 120 </span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="gallery-detail.php" class="album-photo">
                                <span class="counter">05</span>
                                <img src="http://lorempixel.com/400/200/?x=5" alt="Album 5">
                            </a>
                            <a href="gallery-detail.php" class="album-detail group">
                                <span class="left"> Okay, last album, please!</span>
                                <span class="right"> 20</span>
                            </a>
                        </li>
                    </ul>
                </div>

            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
