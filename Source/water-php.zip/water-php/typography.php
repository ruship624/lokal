<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="typography-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <a href="home.php" class="menu-button left">=</a>
                    <h1>Typography</h1>
                </div>
            </div>
            <div class="ui-body margpage">
                
                <h1 class="">H1</h1>
                <h1 class="mini">H1 Mini</h1>
                <h1 class="special">H1 special</h1>
                <h1 class="special mini">H1 Special Mini</h1>
                <h1 class="border"> H1 Border </h1>
                <!---------------------------------------------------------------------------------------->
                
                    
                <h2 class="">h2</h2>
                <h2 class="mini">h2 Mini</h2>
                <h2 class="special">h2 special</h2>
                <h2 class="special mini">h2 Special Mini</h2>
                <h2 class="border"> H2 Border </h1>
                <!---------------------------------------------------------------------------------------->
                
                <br>
                <br>
                <br>
                    
                <h1 class="special mini">Content Box - Type 1</h1>
                <div class="content-box type-1">
                    <div class="head group">
                        <a href="#" class="title">Oil N Gas Company beats Apple.</a>
                        <div class="image">
                            <a href="#"> <img src="http://lorempixel.com/500/170/?x=1" alt="Image">  </a>
                        </div>
                    </div>
                    <div class="content">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                    </div>
                    <div class="foot group">
                        <span class="date left"> 26-Jan-13</span>
                        <a href="#" class="read-more right">Read More</a>
                    </div>
                </div>
                <br>
                <br>
                <br>
                <!---------------------------------------------------------------------------------------->



                    
                
                <h1 class="special mini">Content Box - Type 2</h1>
                <div class="content-box no-pad type-2">
                    <a class="image" href="#"> <img src="http://lorempixel.com/500/170/?x=2" alt="Image"> </a>
                    <div class="head group pad title">
                        Built Google Chrome > Made it open source
                    </div>
                    <div class="content pad">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    </div>
                    <div class="group foot">
                        <a href="#" class="left highlight"> View Photos</a>
                        <a href="http://rahulv.com" target="_blank" class="right highlight"> View Website</a>
                    </div>  
                </div>
                <br>
                <br>
                <br>
                <!---------------------------------------------------------------------------------------->
                    
                
                
                <h1 class="special mini">Gallery items</h1>
                <div class="gallery">
                    <ul>
                        <li>
                            <a href="#" class="album-photo">
                                <span class="counter">01</span>
                                <img src="http://lorempixel.com/266/200/?x=3" alt="Album 1">
                            </a>
                            <a href="#" class="album-detail group">
                                <span class="left"> Sharp Colors and Fonts </span>
                                <span class="right"> 3 </span>
                            </a>
                        </li>  
                    </ul>
                </div>
                <br>
                <br>
                <br>
                <!---------------------------------------------------------------------------------------->
                
                
                <h1 class="special mini">1 column</h1>
                <div class="column-container column-1 group">
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                </div>
                
                <div class="gallery-items" data-columns="1">
                    <div class="container group">
                        <ul>    
                            <?php
                            $total = 2;
                            for($i=1; $i<=$total; $i++){
                                $imageURL = "http://lorempixel.com/500/170/?x=" . rand($i*100, 1000);
                                ?>
                                <li>
                                    <a href="#" class="item image" data-ajax="false">
                                        <img src="<?=$imageURL;?>" alt="Photo <?=$i;?>">
                                    </a>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                
                <br>
                <!---------------------------------------------------------------------------------------->
                
                
                
                
                
                
                <h1 class="special mini">2 column</h1>
                <div class="column-container column-2 group">
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                </div>
                
                <div class="gallery-items" data-columns="2">
                    <div class="container group">
                        <ul>
                            <?php
                            $total = 4;
                            for($i=1; $i<=$total; $i++){
                                $imageURL = "http://lorempixel.com/500/370/?x=" . rand($i*100, 1000);
                                ?>
                                <li>
                                    <a href="#" class="item image" data-ajax="false">
                                        <img src="<?=$imageURL;?>" alt="Photo <?=$i;?>">
                                    </a>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                
                <br>
                <!---------------------------------------------------------------------------------------->
                
                
                
                
                
                
                
                
                <h1 class="special mini">3 column</h1>
                <div class="column-container column-3 group">
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                </div>
                
                
                <div class="gallery-items" data-columns="3">
                    <div class="container group">
                        <ul>
                            <?php
                            $total = 6;
                            for($i=1; $i<=$total; $i++){
                                $imageURL = "http://lorempixel.com/500/400/?x=" . rand($i*100, 1000);
                                ?>
                                <li>
                                    <a href="#" class="item image" data-ajax="false">
                                        <img src="<?=$imageURL;?>" alt="Photo <?=$i;?>">
                                    </a>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                
                <br>
                <!---------------------------------------------------------------------------------------->
                
                
                
                
                
                <h1 class="special mini">4 column</h1>
                
                <div class="column-container column-4 group">
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                </div>
                
                
                <div class="gallery-items" data-columns="4">
                    <div class="container group">
                        <ul>
                            <?php
                            $total = 8;
                            for($i=1; $i<=$total; $i++){
                                $imageURL = "http://lorempixel.com/500/400/?x=" . rand($i*100, 1000);
                                ?>
                                <li>
                                    <a href="#" class="item image" data-ajax="false">
                                        <img src="<?=$imageURL;?>" alt="Photo <?=$i;?>">
                                    </a>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                
                <br>
                <br>
                <!---------------------------------------------------------------------------------------->
                
                
                
                <h1 class="special mini">Simple Lists</h1>
                <br>
                    
                <div class="content-box type-1">
                    <a href="#" class="title link"> Adidas <span class="arrow"></span></a>
                </div>
                <div class="content-box type-1">
                    <a href="#" class="title link"> Microsoft <span class="arrow"></span></a>
                </div>
                <div class="content-box type-1">
                    <a href="#" class="title link"> Google <span class="arrow"></span></a>
                </div>
                <div class="content-box type-1">
                    <a href="#" class="title link"> Amazon <span class="arrow"></span></a>
                </div>
                
                
                <br>
                <br>
                <!---------------------------------------------------------------------------------------->
                



                <h1 class="special mini">Forms</h1>
            
                <div class="content-box theme-text group type-1">
                    <form action="send-email.php" method="post">
                        <input type="text" id="contact-name" required name="contact-name" class="input" placeholder="Requred Text">
                        <input type="email" id="contact-email" required name="contact-email" class="input" placeholder="Email">
                        <input type="tel" id="contact-tel" name="contact-tel" class="input" placeholder="Optional Phone">
                        <textarea id="contact-message" required name="contact-message" class="textarea" placeholder="Textarea"></textarea>
                    </form>
                </div>

                <br>
                <br>
                <!---------------------------------------------------------------------------------------->
                





                <h1 class="mini">Links / Buttons</h1>
            
                <input type="submit" class="button" data-role="none" id="submit" name="submit" value="Normal Button">                
                <input type="submit" class="button large" data-role="none" id="submit" name="submit" value="Large Button">
                <div class="group">
                    <input type="submit" class="left button small" data-role="none" id="submit" name="submit" value="Left button">
                    <input type="submit" class="right button small" data-role="none" id="submit" name="submit" value="right button">
                </div>
                
                <br>
                <!---------------------------------------------------------------------------------------->
                



                
                
                
                <h1 class="special mini">Dark page Footer </h1>

                <div class="dark-page">
                    
                    <div id="footer" class="footer">
                        <div class="padpage group">
                            <div class="social left ">
                                <ul class="child-left">
                                    <li> <a href="#" class="twitter" title="Follow us on Twitter"></a> </li>
                                    <li> <a href="#" class="facebook" title="Like us on Facebook" ></a> </li>
                                    <li> <a href="#" class="linkedin" title="Follow us on Linkedin"></a> </li>
                                </ul>
                            </div>
                            <div class="slogan right">
                                You start the ending...
                            </div>
                        </div>
                    </div>
                </div>
                
                <br>
                <br>
                <!---------------------------------------------------------------------------------------->
                






                <h1 class="special mini">Normal page Footer</h1>
                
                <div id="footer" class="footer">
                    <div class="padpage group">
                        <div class="social left ">
                            <ul class="child-left">
                                <li> <a href="#" class="twitter" title="Follow us on Twitter"></a> </li>
                                <li> <a href="#" class="facebook" title="Like us on Facebook" ></a> </li>
                                <li> <a href="#" class="linkedin" title="Follow us on Linkedin"></a> </li>
                            </ul>
                        </div>
                        <div class="slogan right">
                            You start the ending...
                        </div>
                    </div>
                </div>                    
            
                <br>
                <br>
                <!---------------------------------------------------------------------------------------->
                




                <h1 class="special mini">Messages</h1>
                <br>

                <div class="success-message message">Success Message.</div>
                <div class="warning-message message">Warning Message.</div>
                <div class="error-message message">Error Message.</div>
                <div class="notification-message message">Notification Message.</div>
            
            
            
        
        </div>

<?php include "includes/footer.php";?>
