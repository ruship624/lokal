<?php include "includes/header.php";?>
<!-- Add your site or application content here -->

        <div id="contact-page" class="page" data-theme="a" data-role="page">
            
            <div id="header" data-role="header">
                <div class="margpage">
                    <h1>Contact Us</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                    <div class="content-box theme-text bottom-margin-killer type-1">
                        51st street, 5th Avenue<br/>
                        New York City,<br/>
                        The US
                        <div id="map" class="map hide" data-location="Sharjah Airport Free Zone"></div>
                    </div>
                    
                    <a href="#" class="map-control" data-target="#map"></a>
                    
                    <div class="content-box theme-text group type-1">
                        <a href="tel:+971551231231" class="left"> Phone </a>
                        <a href="tel:+971551231231" class="right"> +971551231231 </a>
                    </div>
                    
                    <div class="content-box theme-text group type-1">
                        <a href="mailto:someone@example.com" class="left"> Email </a>
                        <a href="mailto:someone@example.com" class="right"> someone@example.com</a>
                    </div>
                    <div class="border"></div>
                    
                    <div class="content-box theme-text group type-1">
                        <div class="success-message message">Thank you for contacting us.</div>
                        <div class="title"> Write To Us </div>
                        <form action="send-email.php" method="post">
                            <input type="text" id="contact-name" required name="contact-name" class="input" placeholder="Name">
                            <input type="email" id="contact-email" required name="contact-email" class="input" placeholder="Email">
                            <input type="tel" id="contact-tel" name="contact-tel" class="input" placeholder="Phone">
                            <textarea id="contact-message" required name="contact-message" class="textarea" placeholder="Message"></textarea>
                            
                            <input type="submit" class="button" data-role="none" id="submit" name="submit" value="Send">
                        </form>
                    </div>

            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
