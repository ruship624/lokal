<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="about-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <!--<h2>Water</h2>-->
                    <h1>About Water</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                <div class="column-container column-2 group">
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                    <p class="column">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.
                    </p>
                </div>
                    
                <div class="flexslider">
                    <ul class="slides">
                        <li>
                            <img src="images/sample/image2.jpg" alt="Info">
                        </li>
                        <li>
                            <img src="images/sample/image1.jpg" alt="Info">
                        </li>
                    </ul>
                </div>
                <p class="border">
                    Aliquam augue mi, luctus at pharetra vel, lacinia dignissim ipsum. Maecenas luctus elit ac eros varius at molestie elit adipiscing. Etiam pretium, lectus vitae euismod hendrerit, quam nibh fringilla libero.
                </p>
                
                
                        
                <h2> Our Tweets </h2>
                
                <ul id="twitter_update_list" class="border">
                  <div style="text-align: center; width: 100%">
                    <img src="images/ajax-loader.gif" alt="loader">
                  </div>
                </ul>
                <script type="text/javascript" src="http://twitter.com/javascripts/blogger.js"></script>
                <!-- link doesn't work anymore -->
                <!--<script type="text/javascript" src="http://twitter.com/statuses/user_timeline/rahul_vagadiya.json?callback=twitterCallback2&count=5"></script>-->
                <script type="text/javascript" src="https://api.twitter.com/1/statuses/user_timeline.json?screen_name=rahul_vagadiya&callback=twitterCallback2&count=10"></script>
                
            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
