<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="blog-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <!--<h2>Water</h2>-->
                    <h1>The Blog</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                <ul class="general blog listing">
                    <li>
                        <div class="content-box type-1">
                            <div class="head group">
                                <div class="date right"></div>
                                <a href="blog-detail.php" class="title">Oil N Gas Company beats Apple.</a>
                                <div class="image">
                                    <a href="blog-detail.php"> <img src="images/blog/image3.jpg" alt="Oil N Gas"> </a>
                                </div>
                            </div>
                            <div class="content">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </div>
                            <div class="foot group">
                                <span class="date left"> 26-Jan-13</span>
                                <a href="blog-detail.php" class="read-more right">Read More</a>
                            </div>
                        </div>
                    </li>
                    
                    
                    
                    <li>
                        <div class="content-box type-1">
                            <div class="head group">
                                <a href="blog-detail.php" class="title">Google Plus second to Facebook in the social war!</a>
                                <div class="image">
                                    <a href="blog-detail.php"> <img src="images/blog/image2.jpg" alt="G+"> </a>
                                </div>
                            </div>
                            <div class="content">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </div>
                            <div class="foot group">
                                <span class="date left"> 26-Jan-13</span>
                                <a href="blog-detail.php" class="read-more right">Read More</a>
                            </div>
                        </div>
                    </li>
                    
                    
                    
                    <li>
                        <div class="content-box type-1">
                            <div class="head group">
                                <a href="blog-detail.php" class="title">Oil N Gas Company beats Apple.</a>
                            </div>
                            <div class="content">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </div>
                            <div class="foot group">
                                <span class="date left"> 26-Jan-13</span>
                                <a href="blog-detail.php" class="read-more right">Read More</a>
                            </div>
                        </div>
                    </li>
                    
                </ul>

            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
