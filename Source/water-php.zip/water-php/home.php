<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="home-page" class="page dark-page" data-theme="a" data-role="page">
            <div class="black-overlay"></div>
            <div id="header" data-role="header">
                <div class="margpage">
                    <h1>Water</h1>
                    <a href="info.php" data-role="none" data-transition="slideup" class="top-button left">i</a>
                </div>
            </div>
            <div class="ui-body padpage">
                
                <div class="menu">
                    <ul class="child-left">
                        <li>
                            <a href="about.php" class="menu-item">
                                <img src="images/home-icons/icon-about.png" alt="About">
                                <span>About</span>
                            </a>
                        </li>
                        <li>
                            <a href="services.php" class="menu-item">
                                <img src="images/home-icons/icon-products.png" alt="Services">
                                <span>Services</span>
                            </a>
                        </li>
                        <li>
                            <a href="blog.php" class="menu-item">
                                <img src="images/home-icons/icon-blog.png" alt="Blog">
                                <span>Blog</span>
                            </a>
                        </li>
                        
                        
                        
                        
                        <li>
                            <a href="gallery.php" class="menu-item">
                                <img src="images/home-icons/icon-gallery.png" alt="Gallery">
                                <span>Gallery</span>
                            </a>
                        </li>
                        <li>
                            <a href="join-us.php" class="menu-item">
                                <img src="images/home-icons/icon-careers.png" alt="Join Us">
                                <span>Join Us</span>
                            </a>
                        </li>
                        
                        
                        
                        <li>
                            <a href="videos.php" class="menu-item">
                                <img src="images/home-icons/icon-videos.png" alt="Videos">
                                <span>Videos</span>
                            </a>
                        </li>
                        <li>
                            <a href="portfolio.php" class="menu-item">
                                <img src="images/home-icons/icon-portfolio.png" alt="Portfolio">
                                <span>Portfolio</span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="typography.php" class="menu-item">
                                <img src="images/home-icons/icon-typography.png" alt="Typography">
                                <span>Typography</span>
                            </a>
                        </li>
                        <li>
                            <a href="contact.php" class="menu-item">
                                <img src="images/home-icons/icon-contact.png" alt="Contact">
                                <span>Contact</span>
                            </a>
                        </li>
                    </ul>
                        
                        
                        
                </div>
                
                
            </div>
            <div id="footer" data-role="footer">
                <div class="padpage group">
                    <div class="social left ">
                        <ul class="child-left">
                            <li> <a href="#" class="twitter" title="Follow us on Twitter"></a> </li>
                            <li> <a href="#" class="facebook" title="Like us on Facebook" ></a> </li>
                            <li> <a href="#" class="linkedin" title="Follow us on Linkedin"></a> </li>
                        </ul>
                    </div>
                    <div class="slogan right">
                        You start the ending...
                    </div>
                </div>
            </div>
            
        
        </div>

<?php include "includes/footer.php";?>
