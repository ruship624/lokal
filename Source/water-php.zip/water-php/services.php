<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="services-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <!--<h2>Water</h2>-->
                    <h1>Our Services</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                <ul class="general services products">
                    <li>
                        <div class="content-box type-1">
                            <div class="line-graphic"></div>
                            <div class="head group">
                                <span class="title left">IT Solutions</span>
                                <img src="images/icons/icon-mac.png" alt="Mac" class="right icon">
                            </div>
                            <div class="content">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </div>
                        </div>
                    </li>
                    
                    <li>
                        <div class="content-box type-1">
                            <div class="line-graphic"></div>
                            <div class="head group">
                                <span class="title left">Sales Advisory</span>
                                <img src="images/icons/icon-salesman.png" alt="Sales" class="right icon">
                            </div>
                            <div class="content">
                                <p>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                                </p>
                                <p>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                                </p>
                            </div>
                        </div>
                    </li>
                    
                    
                    <li>
                        <div class="content-box type-1">
                            <div class="line-graphic"></div>
                            <div class="head group">
                                <span class="title left">Waterproofing</span>
                            </div>
                            <div class="content">
                                <p>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                                </p>
                                <p>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                                </p>
                            </div>
                        </div>
                    </li>
                    
                </ul>

            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
