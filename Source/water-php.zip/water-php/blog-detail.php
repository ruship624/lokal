<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="blog-detail-page" class="page" data-theme="a" data-role="page">
            
            <!--<a href="blog.php" class="top-button left"><</a>-->
            <div id="header" data-role="header">
                <div class="margpage">
                    <!--<h2>Water</h2>-->
                    <a href="blog.php" class="menu-button "><</a>
                    <h1>The Blog</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                <div class="blog">
                    
                    <div class="content-box type-1">
                        <div class="head group">
                            <span class="title">Google Plus second to Facebook in the social war!</span>
                            <div class="image">
                                <img src="images/blog/image2.jpg" alt="G+">
                            </div>
                        </div>
                        <div class="content">
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </p>
                            <p>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </p>
                            
                        </div>
                        <div class="foot group">
                            <span class="date left"> 26-Jan-13</span>
                            <div class="right">
                                <iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fthemeforest.net%2Fuser%2Ftheunexpected1%2Fportfolio&amp;send=false&amp;layout=button_count&amp;width=100&amp;show_faces=true&amp;font&amp;colorscheme=light&amp;action=like&amp;height=21&amp;appId=517694484925948" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe>
                            </div>
                        </div>
                        <div class="group">
                            <h2> Comments </h2>
                            <div class="comments">
                                <?php for($i=0; $i<3; $i++){ ?>
                                <div class="comment border">
                                    <div class="comment-head group">
                                        <div class="title left"> John Darwington</div>
                                        <div class="date right"> <?=23+($i*$i);?> Jan '13 </div>
                                    </div>
                                    <div class="comment-body">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text.
                                    </div>
                                </div>
                                <?php }?>
                            </div>
                            
                            <h2> Write a comment </h2>
                            <div class="success-message message">Thank you for your comment, it is now awaiting moderation.</div>
                            <form action="send-comment.php" method="post">
                                <input type="text" id="comment-name" required name="comment-name" class="input" placeholder="Name">
                                <input type="email" id="comment-email" required name="comment-email" class="input" placeholder="Email">
                                <textarea id="comment-message" required name="comment-message" class="textarea" placeholder="Comment"></textarea>
                                <input type="submit" class="button" data-role="none" id="submit" name="submit" value="Post">
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
