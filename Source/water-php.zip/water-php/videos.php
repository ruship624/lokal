<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="videos-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <h1>Staff picked Videos</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                
                
                <div class="gallery-items" data-columns="3">
                    <div class="title loading"> Loading Videos...</div>
                    
                    <div class="container hide group" >
                        <ul>
                            <?php
                            $total = 2;
                            for($i=1; $i<=$total; $i++){ ?>
                            <li>
                                <iframe src="http://player.vimeo.com/video/44149205?byline=0&amp;portrait=0" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
                            </li>
                            <li>
                                <iframe src="http://player.vimeo.com/video/55698309?byline=0&amp;portrait=0&amp;badge=0&amp;color=919191" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
                            </li>
                            <li>
                                <iframe src="http://player.vimeo.com/video/58150375?title=0&amp;byline=0&amp;portrait=0&amp;badge=0&amp;color=919191" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
                            </li>
                            <li>
                                <iframe src="http://player.vimeo.com/video/56982286?title=0&amp;byline=0&amp;portrait=0&amp;badge=0&amp;color=f20c4d" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
                            </li>
                            <?php } ?>
                        </ul>
                        
                    </div>
                </div>
                
                
                

            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
