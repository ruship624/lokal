            <div id="footer" class="footer">
                <div class="padpage group">
                    <div class="social left ">
                        <ul class="child-left">
                            <li> <a href="#" class="twitter" title="Follow us on Twitter"></a> </li>
                            <li> <a href="#" class="facebook" title="Like us on Facebook" ></a> </li>
                            <li> <a href="#" class="linkedin" title="Follow us on Linkedin"></a> </li>
                        </ul>
                    </div>
                    <div class="slogan right">
                        You start the ending...
                    </div>
                </div>
            </div>