<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="gallery-detail-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <a href="gallery.php" class="menu-button "><</a>
                    <h1>Galleria</h1>                    
                    <a href="home.php" class="menu-button left">=</a>
                    <?php $columns = rand(1,4);?>
                </div>
            </div>
            <div class="ui-body margpage">
                <center>
                <h1 class="mini"><?=$columns==1? ($columns." Column") : ($columns . " Columns");?> [<a href="javascript:window.location = window.location;">Refresh?</a>]</h1>
                </center>
                
                <div class="gallery-items" data-columns="<?=$columns;?>">
                    <div class="title loading"> Loading Photos...</div>
                    
                    <div class="container hide group" >
                        <ul>
                            <?php
                            $total = 4*$columns;
                            for($i=1; $i<=$total; $i++){
                                $imageURL = "images/gallery/image" . $i . ".jpg"; ?>
                                <li>
                                    <a href="<?=$imageURL;?>" class="item image" data-ajax="false">
                                        <img src="<?=$imageURL;?>" alt="Photo <?=$i;?>">
                                    </a>
                                </li>
                            <?php } ?>
                        </ul>
                        
                    </div>
                </div>
                
                
                

            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
