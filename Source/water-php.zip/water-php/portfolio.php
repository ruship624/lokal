<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="portfolio-page" class="page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <h1>Company Portfolio</h1>
                    <a href="home.php" class="menu-button left">=</a>
                </div>
            </div>
            <div class="ui-body margpage">
                
                <h3 class="border"> Style 1: Image | Title</h3>
                <ul class="general">
                    <li>
                        <div class="content-box no-pad type-2">
                                <div class="image"> <img src="http://lorempixel.com/500/170/?x=1" alt="Image"> </div>
                                <a href="#" class="head group pad title">
                                    Created a short messaging social system called Twitter
                                </a>
                                <div class="content pad">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                </div>
                                <div class="group foot">
                                    <a href="gallery-detail.php" class="left highlight"> View Photos</a>
                                    <a href="http://rahulv.com" target="_blank" class="right highlight"> View Website</a>
                                </div>  
                        </div>
                    </li>
                    
                    <li>
                        <div class="content-box no-pad type-2">
                                <div class="image no-ajax"> <img src="http://lorempixel.com/500/170/?x=2" alt="Image"> </div>
                                <div class="head group pad title">
                                    Founded Facebook during pass time
                                </div>
                                <div class="content pad">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                </div>
                                <div class="group foot">
                                    <a href="gallery-detail.php" class="left highlight"> View Photos</a>
                                    <a href="http://rahulv.com" target="_blank" class="right highlight"> View Website</a>
                                </div>  
                        </div>
                    </li>
                </ul>
                
                
                
                
                <br/>
                <br/>
                <br/>
                <h3 class="border"> Style 2: Title | Image </h3>
                <ul class="general">
                    <li>
                        <div class="content-box no-pad type-2">
                                <div class="head group pad title">
                                    Developed Instagram and other small projects
                                </div>
                                <div class="image"> <img src="http://lorempixel.com/500/170/?x=3" alt="Image"> </div>
                                <div class="content pad">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                </div>
                                <div class="group foot">
                                    <a href="gallery-detail.php" class="left highlight"> View Photos</a>
                                    <a href="http://rahulv.com" target="_blank" class="right highlight"> View Website</a>
                                </div>  
                        </div>
                    </li>
                    
                    <li>
                        <div class="content-box no-pad type-2">
                                <div class="head group pad title">
                                    Built Google Chrome > Made it open source
                                </div>
                                <div class="image"> <img src="http://lorempixel.com/500/170/?x=4" alt="Image"> </div>
                                <div class="content pad">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                </div>
                                <div class="group foot">
                                    <a href="gallery-detail.php" class="left highlight"> View Photos</a>
                                    <a href="http://rahulv.com" target="_blank" class="right highlight"> View Website</a>
                                </div>  
                        </div>
                    </li>
                </ul>
                
                
                
                
                <br/>
                <br/>                
                <h3 class="border"> Clients </h3>
                <div class="content-box type-1">
                    <a href="#" class="title link"> Adidas <span class="arrow"></span></a>
                </div>
                <div class="content-box type-1">
                    <a href="#" class="title link"> Microsoft <span class="arrow"></span></a>
                </div>
                <div class="content-box type-1">
                    <a href="#" class="title link"> Google <span class="arrow"></span></a>
                </div>
                <div class="content-box type-1">
                    <a href="#" class="title link"> Amazon <span class="arrow"></span></a>
                </div>
                <br/>
                <br/>                
                
                
            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
