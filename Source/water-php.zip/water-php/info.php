<?php include "includes/header.php";?>
<!-- Add your site or application content here -->
        <div id="info-page" class="page dark-page" data-theme="a" data-role="page">
            <div id="header" data-role="header">
                <div class="margpage">
                    <h1>Water</h1>
                    <a href="home.php" data-role="none" data-transition="slideup" data-direction="reverse" class="top-button left">=</a>
                </div>
            </div>
            <div class="ui-body padpage">
                
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eu mi ac lectus varius iaculis. Sed lacus lectus, pharetra ac imperdiet sed, tempor nec nulla. Vestibulum eu ante eros.
                </p>
                <div class="flexslider">
                    <img src="images/sample/image1.jpg" alt="Info">
                </div>
                <p>
                    Aliquam augue mi, luctus at pharetra vel, lacinia dignissim ipsum. Maecenas luctus elit ac eros varius at molestie elit adipiscing. Etiam pretium, lectus vitae euismod hendrerit, quam nibh fringilla libero, nec facilisis sapien justo sed tellus.
                </p>


                
            </div>
            
            
            <?php include "includes/footer-social.php"?>
            
        
        </div>

<?php include "includes/footer.php";?>
